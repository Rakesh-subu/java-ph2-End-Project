package oes.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class DbUtil {
	public static Connection dbcon() throws ClassNotFoundException,SQLException{
	Class.forName(DbConstantPool.DRIVER_CLASS);
	Connection con=DriverManager.getConnection(DbConstantPool.DB_URL,DbConstantPool.USERNAME,DbConstantPool.PASSWORD);
	return con;
		
	}

}
